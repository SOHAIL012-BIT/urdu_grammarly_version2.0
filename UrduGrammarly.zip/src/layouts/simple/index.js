export { default } from './SimpleLayout';
