// ----------------------------------------------------------------------

const account = {
  displayName: 'Muhammad Sohail Abbas',
  email: 'sohailabbas@gmail.com',
  photoURL: '/assets/images/avatars/avatar_default.jpg',
};

export default account;
