export { default } from './ScrollToTop';
